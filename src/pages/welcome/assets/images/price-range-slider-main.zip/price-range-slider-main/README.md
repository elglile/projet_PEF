![Logo](https://raw.githubusercontent.com/codzsword/price-range-slider/main/price-range-slider.png)

# Price Slider With Min-max Input in Html Css & Javascript

In this tutorial, we'll build a double range slider with HTML, CSS, and JavaScript. This slider features two thumbs, allowing users to set both minimum and maximum values—ideal for range filters on product or service category pages. 

[![youtube](https://img.shields.io/badge/YouTube-red?style=for-the-badge&logo=youtube&logoColor=white)](https://youtu.be/ujncLU2bt4k)


## Key Features

- Ideal for Range Filters
- Enhanced User Experience
